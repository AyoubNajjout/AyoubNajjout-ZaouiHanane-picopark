#include "HelloWorldScene.h"
#include "level1CutScene.h"
#include "level3.h"
#include "level3Part2.h"
#include"gameover.h"

#include"physics/CCPhysicsBody.h"

USING_NS_CC;

Scene* level3::createScene()
{
    auto sence = level3::createWithPhysics();
    //sence->getPhysicsWorld()->setDebugDrawMask(PhysicsWorld::DEBUGDRAW_ALL);

    auto layer = level3::create();
    layer->setPhysicsWorld(sence->getPhysicsWorld());
    sence->addChild(layer);
    return sence;
}


auto parentScene = Scene::create();
// Print useful error message instead of segfaulting when files are not there.
static void problemLoading(const char* filename)
{
    printf("Error while loading: %s\n", filename);
    printf("Depending on how you compiled you might have to add 'Resources/' in front of filenames in HelloWorldScene.cpp\n");
}

// on "init" you need to initialize your instance
bool level3::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Scene::init())
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();
    auto edgeBody = PhysicsBody::createEdgeBox(visibleSize, PHYSICSBODY_MATERIAL_DEFAULT, 3);

    auto edgeNode = Node::create();
    edgeNode->setPosition(Point(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));

    edgeNode->setPhysicsBody(edgeBody);

    this->addChild(edgeNode);
    auto background = Sprite::create("background.png");
    if (background == nullptr)
    {
        problemLoading("'background.png'");
    }
    else
    {
        // position the sprite on the center of the screen
        background->setPosition(Point(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
        background->setScale(2);
        this->addChild(background, 0);
        // add the sprite as a child to this layer

    }

    // gravity
    auto scene = Scene::createWithPhysics();
    scene->getPhysicsWorld()->setDebugDrawMask(PhysicsWorld::DEBUGDRAW_ALL);
    scene->getPhysicsWorld()->setGravity(Vect(0, -500));

    //fixed land 

    auto land = Sprite::create("land.png");
    land->getPhysicsBody()->setMass(0);
    auto landBody = PhysicsBody::createBox(land->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    landBody->setDynamic(false);
    land->setScale(0.7, 1.05);
    land->setPosition(Point(visibleSize.width / 2 + origin.x - 450, visibleSize.height / 2 + origin.y - 320));
    landBody->setDynamic(false);
    land->setPhysicsBody(landBody);
    addChild(land);
    //fixed land 1
    auto land1 = Sprite::create("background.png");
    land1->getPhysicsBody()->setMass(0);
    auto landBody1 = PhysicsBody::createBox(land1->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    landBody1->setDynamic(false);

    land1->setScale(0.98, 0.02);
    land1->setTag(2);
    landBody1->setContactTestBitmask(1);
    landBody1->setCollisionBitmask(1);
    landBody1->setCategoryBitmask(1);
    land1->setPosition(Point(visibleSize.width / 2 + origin.x + 130, visibleSize.height / 2 + origin.y - 340));
    land1->setPhysicsBody(landBody1);
    addChild(land1);
    //fixed land 2
    auto land2 = Sprite::create("land.png");
    land2->getPhysicsBody()->setMass(0);
    auto landBody2 = PhysicsBody::createBox(land2->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    landBody2->setDynamic(false);
    land2->setScale(0.2, 0.55);
    land2->setPosition(Point(visibleSize.width / 2 + origin.x - 40, visibleSize.height / 2 + origin.y - 160));
    land2->setPhysicsBody(landBody2);
    addChild(land2);

    //fixed land 3
    auto land3 = Sprite::create("land.png");
    land3->getPhysicsBody()->setMass(0);
    auto landBody3 = PhysicsBody::createBox(land3->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    landBody3->setDynamic(false);
    land3->setScale(0.20, 0.55);
    land3->setPosition(Point(visibleSize.width / 2 + origin.x - 190, visibleSize.height / 2 + origin.y - 30));
    land3->setPhysicsBody(landBody3);
    addChild(land3);

    //fixed land 4

    auto land4 = Sprite::create("land.png");
    land4->getPhysicsBody()->setMass(0);
    auto landBody4 = PhysicsBody::createBox(land4->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    landBody4->setDynamic(false);
    land4->setScale(0.60, 0.55);
    land4->setPosition(Point(visibleSize.width / 2 + origin.x - 450, visibleSize.height / 2 + origin.y + 100));
    land4->setPhysicsBody(landBody4);
    addChild(land4);

    //fixed land 5


    auto land5 = Sprite::create("land.png");
    land5->getPhysicsBody()->setMass(0);
    auto landBody5 = PhysicsBody::createBox(land5->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    landBody5->setDynamic(false);
    land5->setScale(0.35, 0.35);
    land5->setPosition(Point(visibleSize.width / 2 + origin.x - 505, visibleSize.height / 2 + origin.y + 160));
    land5->setPhysicsBody(landBody5);
    addChild(land5);

    //btn dont touch

    auto btn = Sprite::create("btn.png");
    auto btnBody = PhysicsBody::createBox(btn->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    btn->setPosition(Point(visibleSize.width / 2 + origin.x - 530, visibleSize.height / 2 + origin.y + 190));
    btnBody->setDynamic(false);
    btn->setScale(0.2, 0.35);
    btn->setTag(3);
    btnBody->setCollisionBitmask(1);
    btnBody->setCategoryBitmask(1);
    btnBody->setContactTestBitmask(1);
    btn->setPhysicsBody(btnBody);
    addChild(btn);

    //land 6
    

    

    //land 8
    auto land8 = Sprite::create("land.png");
    land8->getPhysicsBody()->setMass(0);
    auto landBody8 = PhysicsBody::createBox(land8->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    landBody8->setDynamic(false);
    land8->setScale(0.20, 0.55);
    land8->setPosition(Point(visibleSize.width / 2 + origin.x + 130, visibleSize.height / 2 + origin.y - 30));
    land8->setPhysicsBody(landBody8);
    //addChild(land8);
    //door

    auto sprite10 = Sprite::create("door.png");
    auto sprite1Body10 = PhysicsBody::createBox(sprite10->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    sprite10->setPosition(Point(visibleSize.width / 2 + origin.x + 590, visibleSize.height / 2 + origin.y + 170));
    sprite10->setTag(6);
    sprite1Body10->setContactTestBitmask(1);
    sprite1Body10->setCollisionBitmask(1);
    sprite1Body10->setCategoryBitmask(1);
    sprite1Body10->setDynamic(false);
    sprite10->setScale(0.3, 0.2);
    sprite10->setPhysicsBody(sprite1Body10);
   // addChild(sprite10);


    //Avatar

    auto avatar = Sprite::create("avatar1.png");
    auto avatarBody = PhysicsBody::createBox(avatar->getContentSize(), PhysicsMaterial(0, 0, 0));
    avatarBody->setDynamic(true);
    avatar->setPosition(Point(visibleSize.width / 2 + origin.x - 500, visibleSize.height / 2 + origin.y - 266));
    avatar->setScale(0.40, 0.40);
    avatarBody->setMass(0.1);
    avatar->setTag(1);
    avatarBody->setContactTestBitmask(1);
    avatarBody->setCollisionBitmask(1);
    avatarBody->setCategoryBitmask(1);
    avatarBody->setRotationEnable(false);
    avatar->setPhysicsBody(avatarBody);

    addChild(avatar);
    //monster
    auto monster = Sprite::create("monster.png");
    auto monsterBody = PhysicsBody::createBox(monster->getContentSize(), PhysicsMaterial(0, 0, 0));
    monsterBody->setDynamic(false);
    monster->setPosition(Point(visibleSize.width / 2 + origin.x + 520, visibleSize.height / 2 + origin.y + 146));
    monster->setScale(0.6, 0.6);
    monsterBody->setMass(0.1);
    monster->setTag(5);
    monsterBody->setContactTestBitmask(1);
    monsterBody->setCollisionBitmask(1);
    monsterBody->setCategoryBitmask(1);
    
    monsterBody->setRotationEnable(false);
    monster->setPhysicsBody(monsterBody);
    auto moveToA = MoveTo::create(3.0, Point(visibleSize.width / 2 + origin.x + 520, visibleSize.height / 2 + origin.y + 146));
    auto moveToB = MoveTo::create(3.0, Point(visibleSize.width / 2 + origin.x + 270, visibleSize.height / 2 + origin.y + 146));
    auto sequence = Sequence::create(moveToA, moveToB, nullptr);
    auto repeatForever = RepeatForever::create(sequence);
    monster->runAction(repeatForever);
    //addChild(monster);

    
    //row
    auto row = Sprite::create("row.png");
    auto rowBody = PhysicsBody::createBox(row->getContentSize(), PhysicsMaterial(0, 0, 0));
    rowBody->setDynamic(false);
    row->setPosition(Point(visibleSize.width / 2 + origin.x - 630, visibleSize.height / 2 + origin.y + 135));
    row->setScale(0.04, 0.13);
    rowBody->setMass(0.1);
    row->setTag(4);
    rowBody->setContactTestBitmask(1);
    rowBody->setCollisionBitmask(1);
    rowBody->setCategoryBitmask(1);
    rowBody->setRotationEnable(false);
    row->setPhysicsBody(rowBody);

    addChild(row);




    // Add an event listener for contact events
    static int counter = 0;
    auto parentScene = Director::getInstance()->getRunningScene();
    auto contactListener = EventListenerPhysicsContact::create();
    contactListener->onContactBegin = [&](PhysicsContact& contact) {
        auto avatar = contact.getShapeA()->getBody()->getNode();
        auto cont = contact.getShapeB()->getBody()->getNode();
        if (avatar && cont) {
            if (avatar->getTag() == 1 && cont->getTag() == 2) {

                avatar->removeFromParent();
                auto delay = DelayTime::create(0.4); // Delay for 0.4 second
                auto replaceScene = CallFunc::create([]() {
                    auto levelScene = level3::createScene();
                Director::getInstance()->replaceScene(levelScene);
                    });
                auto sequence = Sequence::create(delay, replaceScene, nullptr);
                this->runAction(sequence);

            }
            else if (avatar->getTag() == 1 && cont->getTag() == 3) {
                counter++;
                if (counter % 2 == 1) {
                    avatar->setScale(0.20, 0.20);
                }
                else if (counter % 2 == 0) {
                    avatar->setScale(0.40, 0.40);
                }

            }
            else if (avatar->getTag() == 1 && cont->getTag() == 6) {
                avatar->removeFromParent();
                auto delay = DelayTime::create(0.5); // Delay for 1 second
                auto replaceScene = CallFunc::create([]() {
                    auto levelScene = gameover::createScene();
                Director::getInstance()->replaceScene(levelScene);
                    });
                auto sequence = Sequence::create(delay, replaceScene, nullptr);
                this->runAction(sequence);

            }
            else if (avatar->getTag() == 1 && cont->getTag() == 5) {
                avatar->removeFromParent();
                auto delay = DelayTime::create(0.4); // Delay for 0.4 second
                auto replaceScene = CallFunc::create([]() {
                    auto levelScene = level3::createScene();
                Director::getInstance()->replaceScene(levelScene);
                    });
                auto sequence = Sequence::create(delay, replaceScene, nullptr);
                this->runAction(sequence);

            }
            else if (avatar->getTag() == 1 && cont->getTag() == 4) {
                
                auto delay = DelayTime::create(0.1); // Delay for 0.4 second
                auto replaceScene = CallFunc::create([]() {
                    auto levelScene = level3Part2::createScene();
                Director::getInstance()->replaceScene(levelScene);
                    });
                auto sequence = Sequence::create(delay, replaceScene, nullptr);
                this->runAction(sequence);
            }
            





            





        }
        return true;
    };
    _eventDispatcher->addEventListenerWithSceneGraphPriority(contactListener, avatar);


    // Create a keyboard event listener
    auto keyboardListener = EventListenerKeyboard::create();
    keyboardListener->onKeyPressed = [avatar](EventKeyboard::KeyCode KeyCode, Event* event)
    {

        if (KeyCode == EventKeyboard::KeyCode::KEY_UP_ARROW) {
            auto action1 = JumpBy::create(0.7f, Vec2(20, 50), 80.0f, 1);
            avatar->runAction(action1);
        }
        if (KeyCode == EventKeyboard::KeyCode::KEY_RIGHT_ARROW) {
            auto jump = JumpBy::create(0.7f, Vec2(100, 100), 100.0f, 1);
            MoveBy* moveAction = MoveBy::create(1, Vec2(100, 0));
            RepeatForever* repeatAction = RepeatForever::create(moveAction);
            avatar->runAction(repeatAction);
        }
        if (KeyCode == EventKeyboard::KeyCode::KEY_LEFT_ARROW) {
            auto jump = JumpBy::create(0.7f, Vec2(100, 100), 100.0f, 1);
            MoveBy* moveAction = MoveBy::create(1, Vec2(-150, 0));
            RepeatForever* repeatAction = RepeatForever::create(moveAction);
            avatar->runAction(repeatAction);

        }

    };

    keyboardListener->onKeyReleased = [avatar](EventKeyboard::KeyCode KeyCode, Event* event)
    {
        if (KeyCode == EventKeyboard::KeyCode::KEY_RIGHT_ARROW) {
            avatar->stopAllActions();
        }
        if (KeyCode == EventKeyboard::KeyCode::KEY_LEFT_ARROW) {
            avatar->stopAllActions();
        }

    };

    this->getEventDispatcher()->addEventListenerWithSceneGraphPriority(keyboardListener, avatar);












    return true;
}






