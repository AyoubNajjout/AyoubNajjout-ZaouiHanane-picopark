

#include "HelloWorldScene.h"
#include "level1CutScene.h"
#include "level2.h"



USING_NS_CC;

Scene* HelloWorld::createScene()
{
    return HelloWorld::create();
}



// Print useful error message instead of segfaulting when files are not there.
static void problemLoading(const char* filename)
{
    printf("Error while loading: %s\n", filename);
    printf("Depending on how you compiled you might have to add 'Resources/' in front of filenames in HelloWorldScene.cpp\n");
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Scene::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    /////////////////////////////
    // 2. add a menu item with "X" image, which is clicked to quit the program
    //    you may modify it.

    
    auto play = MenuItemImage::create(
                                           "f.png",
                                           "f1.png",
        CC_CALLBACK_1(HelloWorld::GoTolevel1CutScene, this));
                                    

    if (play == nullptr ||
        play->getContentSize().width <= 0 ||
        play->getContentSize().height <= 0)
    {
        problemLoading("'f.png' and 'f.png'");
    }
    else
    {
        play->setPosition(Point(visibleSize.width/2 + origin.x, visibleSize.height - 380 + origin.y));
        play->setScale(2);
    }
    auto closeItem = MenuItemImage::create(
        "exit.png",
        "exit1.png",
        CC_CALLBACK_1(HelloWorld::menuCloseCallback, this));

    if (closeItem == nullptr ||
        closeItem->getContentSize().width <= 0 ||
        closeItem->getContentSize().height <= 0)

    {
        problemLoading("'exit.png' and 'exit.png'");
    }
    else
    {
        closeItem->setPosition(Point(visibleSize.width / 2 + origin.x, visibleSize.height - 480 + origin.y));
        closeItem->setScale(2);
    }

    // create menu, it's an autorelease object
    auto menu = Menu::create(closeItem,play, NULL);
    menu->setPosition(Vec2::ZERO);
    this->addChild(menu,1);

    

    

    // add "HelloWorld" splash screen"
    auto sprite = Sprite::create("menu.jpg");

    if (sprite == nullptr)
    {
        problemLoading("'menu.jpg'");
    }
    else
    {
        // position the sprite on the center of the screen
        sprite->setPosition(Point(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y + 50));
        sprite->setScale(0.85,0.85);
        this->addChild(sprite, 0);
        // add the sprite as a child to this layer
       
    }
    return true;
}


void HelloWorld::menuCloseCallback(Ref* pSender)
{
    //Close the cocos2d-x game scene and quit the application
    Director::getInstance()->end();

}
void HelloWorld::GoTolevel1CutScene(Ref* pSender)
{
    auto scene = level1CutScene::createScene();
    Director::getInstance()->pushScene(TransitionFade::create(0.01, scene));


}


