

#ifndef __GAME_OVER_H__
#define __GAME_OVER__

#include "cocos2d.h"

class gameover : public cocos2d::Scene
{
public:
    static cocos2d::Scene* createScene();
    virtual bool init();
    // implement the "static create()" method manually
    CREATE_FUNC(gameover);
};

#endif // __GAME_OVER_H__
