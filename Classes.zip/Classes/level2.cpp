#include "HelloWorldScene.h"
#include "level1CutScene.h"
#include "level3CutScence.h"
#include "level3Part2.h"
#include"gameover.h"
#include "level2.h"
#include"physics/CCPhysicsBody.h"

USING_NS_CC;

Scene* level2::createScene()
{
    auto sence =    level2::createWithPhysics();
    //sence->getPhysicsWorld()->setDebugDrawMask(PhysicsWorld::DEBUGDRAW_ALL);

    auto layer = level2::create();
    layer->setPhysicsWorld(sence->getPhysicsWorld());
    sence->addChild(layer);
    return sence;
}


// Print useful error message instead of segfaulting when files are not there.
static void problemLoading(const char* filename)
{
    printf("Error while loading: %s\n", filename);
    printf("Depending on how you compiled you might have to add 'Resources/' in front of filenames in HelloWorldScene.cpp\n");
}

// on "init" you need to initialize your instance
bool level2::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Scene::init())
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();


    auto sprite = Sprite::create("background.png");
    if (sprite == nullptr)
    {
        problemLoading("'background.png'");
    }
    else
    {
        // position the sprite on the center of the screen
        sprite->setPosition(Point(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
        sprite->setScale(2);
        this->addChild(sprite);
        // add the sprite as a child to this layer

    }

    auto land = Sprite::create("land.png");
    land->getPhysicsBody()->setMass(0);
    auto landBody = PhysicsBody::createBox(land->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    landBody->setDynamic(false);
    land->setPosition(Point(visibleSize.width / 2 + origin.x - 900, visibleSize.height / 2 + origin.y - 320));
    landBody->setDynamic(false);
    land->setPhysicsBody(landBody);
    addChild(land);

    //fixed land 2

    auto land1 = Sprite::create("land.png");
    land1->getPhysicsBody()->setMass(0);
    auto landBody1 = PhysicsBody::createBox(land1->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    landBody1->setDynamic(false);
    land1->setPosition(Point(visibleSize.width / 2 + origin.x + 800, visibleSize.height / 2 + origin.y + 110));
    land1->setPhysicsBody(landBody1);
    addChild(land1);



    //mini land
    auto sprite1 = Sprite::create("sprite1.png");
    auto sprite1Body = PhysicsBody::createBox(sprite1->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    sprite1->setPosition(Point(visibleSize.width / 2 + origin.x - 380, visibleSize.height / 2 + origin.y - 230));
    sprite1Body->setDynamic(false);
    sprite1->setScale(0.32, 0.35);
    sprite1->setPhysicsBody(sprite1Body);
    addChild(sprite1);

    auto sprite2 = Sprite::create("sprite1.png");
    auto sprite2Body = PhysicsBody::createBox(sprite2->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    sprite2->setPosition(Point(visibleSize.width / 2 + origin.x - 170, visibleSize.height / 2 + origin.y - 180));
    sprite2Body->setDynamic(false);
    sprite2->setScale(0.6, 0.35);
    sprite2->setPhysicsBody(sprite2Body);
    addChild(sprite2);

    auto sprite3 = Sprite::create("sprite1.png");
    auto sprite3Body = PhysicsBody::createBox(sprite3->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    sprite3->setPosition(Point(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y - 100));
    sprite3Body->setDynamic(false);
    sprite3->setScale(0.2, 0.35);
    sprite3->setPhysicsBody(sprite3Body);
    addChild(sprite3);

    auto sprite4 = Sprite::create("sprite1.png");
    auto sprite4Body = PhysicsBody::createBox(sprite4->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    sprite4->setPosition(Point(visibleSize.width / 2 + origin.x + 200, visibleSize.height / 2 + origin.y - 20));
    sprite4Body->setDynamic(false);
    sprite4->setScale(0.7, 0.6);
    sprite4->setPhysicsBody(sprite4Body);
    addChild(sprite4);

    auto sprite5 = Sprite::create("sprite1.png");
    auto sprite5Body = PhysicsBody::createBox(sprite5->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    sprite5->setPosition(Point(visibleSize.width / 2 + origin.x + 340, visibleSize.height / 2 + origin.y + 15));
    sprite5Body->setDynamic(false);
    sprite5->setScale(0.2, 1.5);
    sprite5->setPhysicsBody(sprite5Body);
    addChild(sprite5);

    // void replay

    auto sprite12 = Sprite::create("sprite1.png");
    auto sprite12Body = PhysicsBody::createBox(sprite1->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    sprite12->setPosition(Point(visibleSize.width / 2 + origin.x - 130, visibleSize.height / 2 + origin.y - 530));
    sprite12Body->setDynamic(false);
    sprite12->setScale(10, 2);
    sprite12->setPhysicsBody(sprite12Body);
    addChild(sprite12);
    sprite12Body->setCollisionBitmask(1);
    sprite12Body->setCategoryBitmask(1);
    sprite12Body->setContactTestBitmask(1);

    //btn dont touch

    auto btn = Sprite::create("btn.png");
    auto btnBody = PhysicsBody::createBox(btn->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    btn->setPosition(Point(visibleSize.width / 2 + origin.x - 160, visibleSize.height / 2 + origin.y - 150));
    btnBody->setDynamic(false);
    btn->setScale(0.2, 0.35);
    btnBody->setCollisionBitmask(1);
    btnBody->setCategoryBitmask(1);
    btnBody->setContactTestBitmask(1);
    btn->setPhysicsBody(btnBody);
    addChild(btn);

    auto btn1 = Sprite::create("btn.png");
    auto btnBody1 = PhysicsBody::createBox(btn1->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    btn1->setPosition(Point(visibleSize.width / 2 + origin.x + 150, visibleSize.height / 2 + origin.y + 10));
    btnBody1->setDynamic(false);
    btn1->setScale(0.12, 0.2);
    btnBody1->setCollisionBitmask(1);
    btnBody1->setCategoryBitmask(1);
    btnBody1->setContactTestBitmask(1);
    btn1->setPhysicsBody(btnBody1);
    addChild(btn1);

    auto btn2 = Sprite::create("btn.png");
    auto btnBody2 = PhysicsBody::createBox(btn2->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    btn2->setPosition(Point(visibleSize.width / 2 + origin.x + 255, visibleSize.height / 2 + origin.y + 10));
    btnBody2->setDynamic(false);
    btn2->setScale(0.12, 0.2);
    btnBody2->setCollisionBitmask(1);
    btnBody2->setCategoryBitmask(1);
    btnBody2->setContactTestBitmask(1);
    btn2->setPhysicsBody(btnBody2);
    addChild(btn2);

    auto btn3 = Sprite::create("btn.png");
    auto btnBody3 = PhysicsBody::createBox(btn3->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    btn3->setPosition(Point(visibleSize.width / 2 + origin.x + 405, visibleSize.height / 2 + origin.y + 108));
    btnBody3->setDynamic(false);
    btn3->setScale(0.12, 0.2);
    btn3->setRotation(-90);
    btnBody3->setCollisionBitmask(1);
    btnBody3->setCategoryBitmask(1);
    btnBody3->setContactTestBitmask(1);
    btn3->setPhysicsBody(btnBody3);
    addChild(btn3);

    //Avatar

    auto avatar = Sprite::create("avatar1.png");
    auto avatarBody = PhysicsBody::createBox(avatar->getContentSize(), PhysicsMaterial(0, 0, 0));
    avatarBody->setDynamic(true);
    avatar->setPosition(Point(visibleSize.width / 2 + origin.x - 600, visibleSize.height / 2 + origin.y - 266));
    avatar->setScale(0.35, 0.35);
    avatarBody->setMass(0.1);
    avatarBody->setRotationEnable(false);
    avatar->setPhysicsBody(avatarBody);
    avatarBody->setContactTestBitmask(1);
    avatarBody->setCollisionBitmask(1);
    avatarBody->setCategoryBitmask(1);


    addChild(avatar);

    //door for level2 

    auto sprite10 = Sprite::create("door.png");
    auto sprite1Body10 = PhysicsBody::createBox(sprite10->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    sprite10->setPosition(Point(visibleSize.width / 2 + origin.x + 550, visibleSize.height / 2 + origin.y + 222));
    sprite1Body10->setDynamic(false);
    sprite10->setScale(0.3, 0.3);
    sprite10->setPhysicsBody(sprite1Body10);
    addChild(sprite10);
    sprite1Body10->setContactTestBitmask(1);
    sprite1Body10->setCollisionBitmask(2);
    sprite1Body10->setCategoryBitmask(1);

    // Set the boundary body as a collision mask for the player's physics body


            // Create a keyboard event listener

    auto keyboardListener = EventListenerKeyboard::create();
    keyboardListener->onKeyPressed = [avatar](EventKeyboard::KeyCode KeyCode, Event* event)
    {

        if (KeyCode == EventKeyboard::KeyCode::KEY_UP_ARROW) {
            auto action1 = JumpBy::create(0.7f, Vec2(50, 50), 80.0f, 1);
            avatar->runAction(action1);
        }
        if (KeyCode == EventKeyboard::KeyCode::KEY_RIGHT_ARROW) {
            auto jump = JumpBy::create(0.7f, Vec2(100, 100), 100.0f, 1);
            MoveBy* moveAction = MoveBy::create(1, Vec2(100, 0));
            RepeatForever* repeatAction = RepeatForever::create(moveAction);
            avatar->runAction(repeatAction);
        }
        if (KeyCode == EventKeyboard::KeyCode::KEY_LEFT_ARROW) {
            auto jump = JumpBy::create(0.7f, Vec2(100, 100), 100.0f, 1);
            MoveBy* moveAction = MoveBy::create(1, Vec2(-70, 0));
            RepeatForever* repeatAction = RepeatForever::create(moveAction);
            avatar->runAction(repeatAction);

        }

    };

    keyboardListener->onKeyReleased = [avatar](EventKeyboard::KeyCode KeyCode, Event* event)
    {
        if (KeyCode == EventKeyboard::KeyCode::KEY_RIGHT_ARROW) {
            avatar->stopAllActions();
        }
        if (KeyCode == EventKeyboard::KeyCode::KEY_LEFT_ARROW) {
            avatar->stopAllActions();
        }

    };

    this->getEventDispatcher()->addEventListenerWithSceneGraphPriority(keyboardListener, avatar);

    // on contact restart game

    auto contactListener = EventListenerPhysicsContact::create();
    contactListener->onContactBegin = [avatar](PhysicsContact& contact) {


        PhysicsBody* x = contact.getShapeA()->getBody();
        PhysicsBody* y = contact.getShapeB()->getBody();


        if (1 == x->getCollisionBitmask() && (1 == y->getCollisionBitmask())) {

            auto scene = level2::createScene();
            Director::getInstance()->replaceScene(TransitionFade::create(0.4, scene));


        }
        if (2 == x->getCollisionBitmask() || (2 == y->getCollisionBitmask())) {

            auto scene2 = level3CutScence::createScene();
            Director::getInstance()->pushScene(TransitionFade::create(0.4, scene2));


        }
        return true;
    };
    this->getEventDispatcher()->addEventListenerWithSceneGraphPriority(contactListener, this);



  

    

    

    
    return true;
}

















