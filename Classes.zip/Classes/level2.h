

#ifndef __level2_SCENE_H__
#define __level2_SCENE_H__

#include "cocos2d.h"


class level2 : public cocos2d::Scene
{
public:
    static cocos2d::Scene* createScene();
    
    virtual bool init();
    
    // a selector callback
    
    
    // implement the "static create()" method manually
    CREATE_FUNC(level2);

    

private:

    
    cocos2d::PhysicsWorld * SenceWorld;
    void setPhysicsWorld(cocos2d::PhysicsWorld * World) { SenceWorld = World; };

    
    
};

#endif 
