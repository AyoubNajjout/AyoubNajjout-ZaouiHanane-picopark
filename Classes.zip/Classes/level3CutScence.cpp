#include "HelloWorldScene.h"
#include "level1CutScene.h"
#include "level3CutScence.h"
#include "level3Part2.h"
#include"gameover.h"
#include "level3.h"
#include"physics/CCPhysicsBody.h"

USING_NS_CC;

Scene* level3CutScence::createScene()
{
    auto sence = level3CutScence::createWithPhysics();
    //sence->getPhysicsWorld()->setDebugDrawMask(PhysicsWorld::DEBUGDRAW_ALL);

    auto layer = level3CutScence::create();
    layer->setPhysicsWorld(sence->getPhysicsWorld());
    sence->addChild(layer);
    return sence;
}


// Print useful error message instead of segfaulting when files are not there.
static void problemLoading(const char* filename)
{
    printf("Error while loading: %s\n", filename);
    printf("Depending on how you compiled you might have to add 'Resources/' in front of filenames in HelloWorldScene.cpp\n");
}

// on "init" you need to initialize your instance
bool level3CutScence::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Scene::init())
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    /////////////////////////////
    auto label = Label::createWithTTF("Start", "fonts/arial.ttf", 32);
    label->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
    addChild(label);

    auto level1 = MenuItemImage::create(
        "lvl3.png",
        "lvl3.png");
    level1->setPosition(Point(visibleSize.width / 2 + origin.x, visibleSize.height - 300 + origin.y));
    level1->setScale(0.2, 0.2);

    auto start = MenuItemImage::create(
        "start.png",
        "start.png",
        CC_CALLBACK_1(level3CutScence::GoToLevel3, this));

    start->setScale(0.2, 0.2);
    if (start == nullptr ||
        start->getContentSize().width <= 0 ||
        start->getContentSize().height <= 0)
    {
        problemLoading("'CloseNormal.png' and 'CloseSelected.png'");
    }
    else
    {
        start->setPosition(Point(visibleSize.width / 2 + origin.x, visibleSize.height - 390 + origin.y));
    }

    auto menu = Menu::create(start, level1, NULL);
    menu->setPosition(Vec2::ZERO);
    this->addChild(menu, 1);

    auto sprite = Sprite::create("background.png");
    if (sprite == nullptr)
    {
        problemLoading("'background.png'");
    }
    else
    {
        // position the sprite on the center of the screen
        sprite->setPosition(Point(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
        sprite->setScale(2);
        this->addChild(sprite);
        // add the sprite as a child to this layer

    }
    auto avatar = Sprite::create("avatar1.png");
    avatar->setScale(0.40, 0.40);
    avatar->setPosition(Point(visibleSize.width / 2 + origin.x, visibleSize.height - 560 + origin.y));
    auto moveToA = MoveTo::create(4.0, Point(visibleSize.width / 2 + origin.x + 150, visibleSize.height - 560 + origin.y));
    auto moveToB = MoveTo::create(4.0, Point(visibleSize.width / 2 + origin.x - 150, visibleSize.height - 560 + origin.y));
    auto sequence = Sequence::create(moveToA, moveToB, nullptr);
    auto repeatForever = RepeatForever::create(sequence);
    avatar->runAction(repeatForever);
    addChild(avatar);

    return true;
}





void level3CutScence::GoToLevel3(Ref* pSender)
{
    auto scene = level3::createScene();
    Director::getInstance()->pushScene(TransitionFade::create(0.01, scene));


}










