

#ifndef __level3CutScence_SCENE_H__
#define __level3CutScence_SCENE_H__

#include "cocos2d.h"


class level3CutScence : public cocos2d::Scene
{
public:
    static cocos2d::Scene* createScene();
    
    virtual bool init();
    
    // a selector callback
    
    
    // implement the "static create()" method manually
    CREATE_FUNC(level3CutScence);

    void GoToLevel3(cocos2d::Ref* sender);

private:

    
    cocos2d::PhysicsWorld * SenceWorld;
    void setPhysicsWorld(cocos2d::PhysicsWorld * World) { SenceWorld = World; };

    
    
};

#endif 
