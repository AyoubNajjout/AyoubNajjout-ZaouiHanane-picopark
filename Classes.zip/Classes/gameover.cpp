

#include "gameover.h"


USING_NS_CC;

Scene* gameover::createScene()
{
    return gameover::create();
}



// on "init" you need to initialize your instance
bool gameover::init()
{
    if (!Scene::init()) {
        return false;
    }
    Size visiblesize = Director::getInstance()->getVisibleSize();
    Point origin = Director::getInstance()->getVisibleOrigin();

    //partie background
    auto mysprite = Sprite::create("bgd.jpg");
    mysprite->setPosition(Point((visiblesize.width / 2) + origin.x, (visiblesize.height / 2 + origin.y + 45)));
    mysprite->setScale(0.9);
    this->addChild(mysprite);

    auto mysprite1 = Sprite::create("endgame.png");
    mysprite1->setPosition(Point((visiblesize.width / 2) + origin.x, (visiblesize.height / 2 + origin.y + 45)));
    mysprite1->setScale(2);
    this->addChild(mysprite1);

    auto avatar = Sprite::create("avatar1.png");
    avatar->setScale(0.6, 0.60);
    avatar->setPosition(Point(visiblesize.width / 2 + origin.x, visiblesize.height -  + origin.y));
    auto moveToA = MoveTo::create(4.0, Point(visiblesize.width / 2 + origin.x + 150, visiblesize.height - 480 + origin.y));
    auto moveToB = MoveTo::create(4.0, Point(visiblesize.width / 2 + origin.x - 150, visiblesize.height - 480 + origin.y));
    auto sequence = Sequence::create(moveToA, moveToB, nullptr);
    auto repeatForever = RepeatForever::create(sequence);
    avatar->runAction(repeatForever);
    addChild(avatar);


    return true;
}



