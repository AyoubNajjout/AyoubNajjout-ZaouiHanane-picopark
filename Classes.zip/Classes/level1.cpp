
#include "HelloWorldScene.h"
#include "level1.h"
#include "level2.h"
#include "level2CutScence.h"
#include "physics/CCPhysicsBody.h"


USING_NS_CC;

Scene* level1::createScene()
{
    auto sence = level1::createWithPhysics();
   

    auto layer = level1::create();
    layer->setPhysicsWorld(sence->getPhysicsWorld());
    sence->addChild(layer);
    return sence;
}



// Print useful error message instead of segfaulting when files are not there.
static void problemLoading(const char* filename)
{
    printf("Error while loading: %s\n", filename);
    printf("Depending on how you compiled you might have to add 'Resources/' in front of filenames in HelloWorldScene.cpp\n");
}

// on "init" you need to initialize your instance
bool level1::init()
{
    //////////////////////////////
    // 1. super init first
    if (!Scene::init())
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();


    auto edgeNode = Node::create();
    edgeNode->setPosition(Point(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));


    this->addChild(edgeNode);
    auto background = Sprite::create("background.png");
    if (background == nullptr)
    {
        problemLoading("'background.png'");
    }
    else
    {
        // position the sprite on the center of the screen

        background->setPosition(Point(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));
        background->setScale(2);
        this->addChild(background, 0);

        // add the sprite as a child to this layer

    }

    // gravity

    auto scene = Scene::createWithPhysics();
    scene->getPhysicsWorld()->setDebugDrawMask(PhysicsWorld::DEBUGDRAW_ALL);
    scene->getPhysicsWorld()->setGravity(Vect(0, -500));

    //fixed land 

    auto land = Sprite::create("land.png");
    land->getPhysicsBody()->setMass(0);
    auto landBody = PhysicsBody::createBox(land->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    landBody->setDynamic(false);
    land->setPosition(Point(visibleSize.width / 2 + origin.x - 260, visibleSize.height / 2 + origin.y - 320));
    landBody->setDynamic(false);
    land->setPhysicsBody(landBody);
    addChild(land);

    //fixed land 2

    auto land1 = Sprite::create("land.png");
    land1->getPhysicsBody()->setMass(0);
    auto landBody1 = PhysicsBody::createBox(land1->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    landBody1->setDynamic(false);
    land1->setPosition(Point(visibleSize.width / 2 + origin.x + 800, visibleSize.height / 2 + origin.y - 320));
    land1->setPhysicsBody(landBody1);
    addChild(land1);



    //mini land

    {
        auto sprite1 = Sprite::create("sprite1.png");
        auto sprite1Body = PhysicsBody::createBox(sprite1->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
        sprite1->setPosition(Point(visibleSize.width / 2 + origin.x + 230, visibleSize.height / 2 + origin.y - 230));
        sprite1Body->setDynamic(false);
        sprite1->setScale(0.2, 0.35);
        sprite1->setPhysicsBody(sprite1Body);
        addChild(sprite1);

        // void replay

        auto sprite12 = Sprite::create("sprite1.png");
        auto sprite12Body = PhysicsBody::createBox(sprite1->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
        sprite12->setPosition(Point(visibleSize.width / 2 + origin.x + 230, visibleSize.height / 2 + origin.y - 530));
        sprite12Body->setDynamic(false);
        sprite12->setScale(1, 1);
        sprite12->setPhysicsBody(sprite12Body);
        addChild(sprite12);
        sprite12Body->setCollisionBitmask(1);
        sprite12Body->setCategoryBitmask(1);
        sprite12Body->setContactTestBitmask(1);

        //btn dont touch

        auto btn = Sprite::create("btn.png");
        auto btnBody = PhysicsBody::createBox(btn->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
        btn->setPosition(Point(visibleSize.width / 2 + origin.x - 100, visibleSize.height / 2 + origin.y - 266));
        btnBody->setDynamic(false);
        btn->setScale(0.2, 0.35);
        btnBody->setCollisionBitmask(1);
        btnBody->setCategoryBitmask(1);
        btnBody->setContactTestBitmask(1);
        btn->setPhysicsBody(btnBody);
        addChild(btn);

        auto btn1 = Sprite::create("btn.png");
        auto btnBody1 = PhysicsBody::createBox(btn->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
        btn1->setPosition(Point(visibleSize.width / 2 + origin.x - 240, visibleSize.height / 2 + origin.y - 266));
        btnBody1->setDynamic(false);
        btn1->setScale(0.2, 0.35);
        btnBody1->setCollisionBitmask(1);
        btnBody1->setCategoryBitmask(1);
        btnBody1->setContactTestBitmask(1);
        btn1->setPhysicsBody(btnBody1);
        addChild(btn1);
    }

    //Avatar

    auto avatar = Sprite::create("avatar1.png");
    auto avatarBody = PhysicsBody::createBox(avatar->getContentSize(), PhysicsMaterial(0, 0, 0));
    avatarBody->setDynamic(true);
    avatar->setPosition(Point(visibleSize.width / 2 + origin.x - 450, visibleSize.height / 2 + origin.y - 266));
    avatar->setScale(0.35, 0.35);
    avatarBody->setMass(0.1);
    avatarBody->setRotationEnable(false);
    avatar->setPhysicsBody(avatarBody);
    avatarBody->setContactTestBitmask(1);
    avatarBody->setCollisionBitmask(1);
    avatarBody->setCategoryBitmask(1);
    addChild(avatar);

    //door for level2 

    auto sprite10 = Sprite::create("door.png");
    auto sprite1Body10 = PhysicsBody::createBox(sprite10->getContentSize(), PHYSICSBODY_MATERIAL_DEFAULT);
    sprite10->setPosition(Point(visibleSize.width / 2 + origin.x + 550, visibleSize.height / 2 + origin.y - 208));
    sprite1Body10->setDynamic(false);
    sprite10->setScale(0.3, 0.3);
    sprite10->setPhysicsBody(sprite1Body10);
    addChild(sprite10);
    sprite1Body10->setContactTestBitmask(1);
    sprite1Body10->setCollisionBitmask(2);
    sprite1Body10->setCategoryBitmask(1);

    // Set the boundary body as a collision mask for the player's physics body


            // Create a keyboard event listener

    auto keyboardListener = EventListenerKeyboard::create();
    keyboardListener->onKeyPressed = [avatar](EventKeyboard::KeyCode KeyCode, Event* event)
    {

        if (KeyCode == EventKeyboard::KeyCode::KEY_UP_ARROW) {
            auto action1 = JumpBy::create(0.7f, Vec2(50, 50), 80.0f, 1);
            avatar->runAction(action1);
        }
        if (KeyCode == EventKeyboard::KeyCode::KEY_RIGHT_ARROW) {
            auto jump = JumpBy::create(0.7f, Vec2(100, 100), 100.0f, 1);
            MoveBy* moveAction = MoveBy::create(1, Vec2(100, 0));
            RepeatForever* repeatAction = RepeatForever::create(moveAction);
            avatar->runAction(repeatAction);
        }
        if (KeyCode == EventKeyboard::KeyCode::KEY_LEFT_ARROW) {
            auto jump = JumpBy::create(0.7f, Vec2(100, 100), 100.0f, 1);
            MoveBy* moveAction = MoveBy::create(1, Vec2(-70, 0));
            RepeatForever* repeatAction = RepeatForever::create(moveAction);
            avatar->runAction(repeatAction);

        }

    };

    keyboardListener->onKeyReleased = [avatar](EventKeyboard::KeyCode KeyCode, Event* event)
    {
        if (KeyCode == EventKeyboard::KeyCode::KEY_RIGHT_ARROW) {
            avatar->stopAllActions();
        }
        if (KeyCode == EventKeyboard::KeyCode::KEY_LEFT_ARROW) {
            avatar->stopAllActions();
        }

    };

    this->getEventDispatcher()->addEventListenerWithSceneGraphPriority(keyboardListener, avatar);

    // on contact restart game

    auto contactListener = EventListenerPhysicsContact::create();
    contactListener->onContactBegin = [avatar](PhysicsContact& contact) {


        PhysicsBody* x = contact.getShapeA()->getBody();
        PhysicsBody* y = contact.getShapeB()->getBody();


        if (1 == x->getCollisionBitmask() && (1 == y->getCollisionBitmask())) {

            auto scene = level1::createScene();
            Director::getInstance()->replaceScene(TransitionFade::create(0.4, scene));


        }
        if (2 == x->getCollisionBitmask() || (2 == y->getCollisionBitmask())) {

            auto scene2 = level2CutScence::createScene();
            Director::getInstance()->pushScene(TransitionFade::create(0.4, scene2));


        }
        return true;
    };
    this->getEventDispatcher()->addEventListenerWithSceneGraphPriority(contactListener, this);



    return true;
}






